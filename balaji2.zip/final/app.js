/****************************************************
 * STATIONERY STORE — FINAL app.js
 * - Single inventory (stationery only)
 * - Barcode scanner (Quagga2)
 * - Manual image upload (Base64)
 * - Inventory + profit
 ****************************************************/

// ================= STORAGE =================
const STORAGE_KEY = "stationaryProducts";

let products = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");

function saveProducts() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
}

// ================= PAGE NAV =================
function showPage(id) {
  document.querySelectorAll(".page").forEach(p => p.classList.add("hidden"));
  const page = document.getElementById(id);
  if (page) page.classList.remove("hidden");

  if (id === "inventory" || id === "shopItems") renderProducts();
  if (id === "profit") renderProfit();
}

// ================= RENDER =================
function getItemsContainer() {
  return (
    document.getElementById("itemsList") ||
    document.getElementById("productList") ||
    document.getElementById("inventoryList")
  );
}

function renderProducts() {
  const list = getItemsContainer();
  if (!list) return;

  if (!products.length) {
    list.innerHTML =
      `<div class="text-gray-500 italic">No stationery items added yet.</div>`;
    return;
  }

  list.innerHTML = products.map(p => `
    <div class="card">
      ${p.imageUrl ? `
        <img src="${p.imageUrl}" style="width:100%;max-height:160px;
        object-fit:contain;border-radius:10px;margin-bottom:8px;">` : ""}
      <div class="font-semibold">${p.name}</div>
      <div class="text-sm text-gray-500">SKU: ${p.sku}</div>
      <div>Qty: ${p.qty}${p.threshold ? ` (Low at ${p.threshold})` : ""}</div>
      <div>Price: ₹${p.price}</div>
      <button class="btn-sell" onclick="sellProduct('${p.sku}')">Sell (-1)</button>
    </div>
  `).join("");
}

function renderProfit() {
  const list = document.getElementById("profitList");
  if (!list) return;

  let total = 0;
  list.innerHTML = products.map(p => {
    const profit = (p.price || 0) * (p.qty || 0);
    total += profit;
    return `
      <div class="card">
        <strong>${p.name}</strong>
        <div>Estimated Value: ₹${profit}</div>
      </div>`;
  }).join("");

  const totalDiv = document.createElement("div");
  totalDiv.className = "card font-bold";
  totalDiv.textContent = `Total Inventory Value: ₹${total}`;
  list.appendChild(totalDiv);
}

// ================= ADD / SELL =================
function addProduct() {
  const skuEl = document.getElementById("pSKU");
  const nameEl = document.getElementById("pName");
  const priceEl = document.getElementById("pPrice");
  const qtyEl = document.getElementById("pQty");
  const thrEl = document.getElementById("pThreshold");
  const imgEl = document.getElementById("pImageUrl");

  const sku = (skuEl.value || "").trim() || Date.now().toString();
  const name = nameEl.value.trim();
  const price = parseFloat(priceEl.value || 0);
  const qty = parseInt(qtyEl.value || 0, 10);
  const threshold = thrEl.value ? parseInt(thrEl.value, 10) : null;
  const imageUrl = imgEl.value || "";

  if (!name || !price || !qty) {
    alert("Please fill Name, Price and Quantity");
    return;
  }

  if (products.some(p => p.sku === sku)) {
    alert("SKU already exists");
    return;
  }

  products.push({ sku, name, price, qty, threshold, imageUrl });
  saveProducts();
  renderProducts();

  skuEl.value = "";
  nameEl.value = "";
  priceEl.value = "";
  qtyEl.value = "";
  thrEl.value = "";
  imgEl.value = "";

  document.getElementById("pImageWrap").style.display = "none";

  alert("Product added successfully");
}

function sellProduct(sku) {
  const p = products.find(x => x.sku === sku);
  if (!p) return;

  if (p.qty <= 0) {
    alert("Out of stock");
    return;
  }

  p.qty--;
  saveProducts();
  renderProducts();

  if (p.threshold && p.qty <= p.threshold) {
    alert(`Low stock alert: ${p.name}`);
  }
}

// ================= IMAGE UPLOAD (BASE64) =================
const uploadInput = document.getElementById("imageUpload");
const imagePreview = document.querySelector("#pImageWrap img");
const imageWrap = document.getElementById("pImageWrap");
const imageUrlInput = document.getElementById("pImageUrl");

if (uploadInput) {
  uploadInput.addEventListener("change", async e => {
    const file = e.target.files[0];
    if (!file) return;
    const base64 = await resizeImage(file, 600, 600);
    imageUrlInput.value = base64;
    imagePreview.src = base64;
    imageWrap.style.display = "block";
  });
}

function resizeImage(file, maxW, maxH) {
  return new Promise(resolve => {
    const reader = new FileReader();
    const img = new Image();
    reader.onload = e => {
      img.onload = () => {
        let w = img.width, h = img.height;
        const ratio = Math.min(maxW / w, maxH / h, 1);
        w *= ratio; h *= ratio;
        const canvas = document.createElement("canvas");
        canvas.width = w; canvas.height = h;
        canvas.getContext("2d").drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", 0.7));
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  });
}

// ================= BARCODE SCANNER =================
let quaggaRunning = false;
let selectedCamera = null;

async function initScanner() {
  const select = document.getElementById("cameraSelect");
  if (!select) return;

  const devices = await navigator.mediaDevices.enumerateDevices();
  const cams = devices.filter(d => d.kind === "videoinput");

  select.innerHTML = cams.map(
    (c, i) => `<option value="${c.deviceId}">${c.label || "Camera " + (i+1)}</option>`
  ).join("");

  selectedCamera = cams[0]?.deviceId;
  select.onchange = () => selectedCamera = select.value;
}

function startScanner() {
  const reader = document.getElementById("reader");
  if (!reader || !window.Quagga) return alert("Scanner not ready");

  Quagga.init({
    inputStream: {
      type: "LiveStream",
      target: reader,
      constraints: {
        deviceId: selectedCamera ? { exact: selectedCamera } : undefined
      }
    },
    decoder: {
      readers: ["ean_reader", "ean_8_reader", "upc_reader", "upc_e_reader"]
    }
  }, err => {
    if (err) return alert("Could not start scanner");
    Quagga.start();
    quaggaRunning = true;

    Quagga.onDetected(data => {
      const code = data.codeResult.code;
      document.getElementById("pSKU").value = code;
      alert("Scanned: " + code);
      stopScanner();
    });
  });
}

function stopScanner() {
  if (window.Quagga && quaggaRunning) {
    Quagga.stop();
    Quagga.offDetected();
  }
  quaggaRunning = false;
  const reader = document.getElementById("reader");
  if (reader) reader.innerHTML = "";
}

// ================= INIT =================
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("addProductBtn");
  if (btn) btn.onclick = e => { e.preventDefault(); addProduct(); };

  const form = document.getElementById("productForm");
  if (form) form.onsubmit = e => { e.preventDefault(); addProduct(); };

  initScanner();
  renderProducts();
});
